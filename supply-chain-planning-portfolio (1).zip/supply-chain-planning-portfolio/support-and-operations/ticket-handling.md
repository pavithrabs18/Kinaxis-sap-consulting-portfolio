# Ticket Handling

## A good ticket contains

- Who is affected and how many people.
- What they were doing and what they expected.
- What happened, with exact messages and screenshots.
- When it started and whether it is still happening.
- Environment and system names, document numbers, and user IDs.

## Working a ticket

1. Acknowledge and set the priority.
2. Ask only the questions that are missing, all at once.
3. Reproduce or confirm from logs.
4. Fix, work around, or escalate with a clear summary.
5. Confirm with the requester before closing.
6. Record the cause and resolution.

## Escalation message pattern

State the impact, what you have checked, what you suspect, what you need, and by when. Escalation is stronger when the next person does not need to repeat any of your work.

## Vendor coordination

- Keep one thread per issue and name the owner of the next action.
- Restate agreed dates and actions at the end of each message.
- Keep the client informed even when you are waiting on a vendor.
