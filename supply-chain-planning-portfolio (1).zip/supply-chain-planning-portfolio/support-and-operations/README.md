# Support and Operations

Practical notes from running support for clients across time zones and languages.

1. `incident-problem-change.md`
2. `ticket-handling.md`
3. `kt-and-sop-writing.md`
