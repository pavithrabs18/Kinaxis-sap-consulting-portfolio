# KT and SOP Writing

## Running a knowledge transfer

1. Agree a topic list and owners before the first session.
2. Record each session and keep a short written summary.
3. Use a real example in every session, not only slides.
4. Ask the receiver to repeat the process back (reverse KT).
5. Track topics and status in one place and mark each topic complete only after reverse KT.
6. Capture open questions and who will answer them.

## Writing an SOP

| Section | Content |
|---|---|
| Purpose | One sentence |
| Scope | When the SOP applies and when it does not |
| Prerequisites | Access, tools, approvals |
| Steps | Numbered, one action each, with expected results |
| Rollback | How to undo each risky step |
| Contacts | Who to call and when |
| History | Version, date, author, change |

## Quality check

- Could a new team member follow it without asking questions?
- Does every step say what success looks like?
- Is every risky step paired with a rollback?
