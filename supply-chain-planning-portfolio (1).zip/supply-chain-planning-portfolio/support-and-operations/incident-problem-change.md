# Incident, Problem, and Change

## Definitions

| Term | Meaning | Goal |
|---|---|---|
| Incident | An unplanned interruption or reduced quality of service | Restore service quickly |
| Problem | The underlying cause of one or more incidents | Remove the cause |
| Change | A planned modification to the environment | Make it safely, with approval and a rollback plan |
| Request | A standard, pre-approved ask | Fulfil it consistently |

## Priority matrix

Priority comes from impact and urgency.

| Impact / Urgency | High urgency | Medium urgency | Low urgency |
|---|---|---|---|
| High impact | P1 | P2 | P3 |
| Medium impact | P2 | P3 | P4 |
| Low impact | P3 | P4 | P4 |

## Habits

- Restore first, investigate second, but capture evidence before it disappears.
- Open a problem record when the same incident recurs.
- Never apply a change without a record, an approver, and a rollback step.
- Close the loop with the user.
