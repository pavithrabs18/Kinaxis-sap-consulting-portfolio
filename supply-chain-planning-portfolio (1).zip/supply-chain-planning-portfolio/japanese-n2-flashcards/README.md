# Japanese N2 Flashcards

An offline flashcard app with work-related N2 vocabulary. Open `index.html` in any browser. No install and no internet needed.

Click the card to flip it. Use Previous, Next, and Shuffle to move around. To add words, edit the `cards` list near the bottom of `index.html`.
