# Translation Practice

1. Read the whole document first and note the purpose and audience.
2. Build a term list before translating, and reuse it.
3. Translate meaning, not word order. Rebuild the sentence in the target language.
4. Keep numbers, dates, document numbers, and system names exactly as they are.
5. Proofread once against the source for accuracy and once alone for natural reading.
6. Ask the author when the source is ambiguous instead of guessing.
7. Keep a before and after log of corrections for future reference.
