# Business Phrases

## Email openings and closings

| Situation | Japanese |
|---|---|
| Opening (regular contact) | お世話になっております。 |
| Closing | よろしくお願いいたします。 |
| Asking to confirm | ご確認をお願いいたします。 |
| Asking for a reply | ご返信いただけますと幸いです。 |
| Sharing a file | 資料を添付いたします。 |

## In meetings and tickets

| Situation | Japanese |
|---|---|
| Understood | 承知しました。 |
| Will check | 確認いたします。 |
| Apology for the delay | 回答が遅くなり申し訳ございません。 |
| Reporting progress | 進捗をご報告いたします。 |
| Asking for clarification | 念のため確認させてください。 |
| Confirming next steps | 次のアクションは以下の通りです。 |

## Habit

After each meeting, send a short summary of decisions, owners, and dates in both languages.
