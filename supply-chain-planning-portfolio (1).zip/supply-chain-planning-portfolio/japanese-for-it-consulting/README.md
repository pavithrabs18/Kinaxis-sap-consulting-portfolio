# Japanese for IT and Supply Chain Consulting

Working vocabulary and phrases for bilingual client communication, translation, and interpretation.

- `glossary.csv`: English, Japanese, reading, and area
- `business-phrases.md`: phrases for email and meetings
- `translation-practice.md`: habits for translating documents
