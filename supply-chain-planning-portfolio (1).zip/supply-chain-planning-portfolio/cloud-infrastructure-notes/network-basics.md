# Network Basics

| Concept | Meaning |
|---|---|
| IP address and subnet | Where a device is on the network and which devices share its segment |
| VLAN | A logical network segment on a shared switch |
| Switch | Connects devices within a segment |
| Router | Connects segments |
| Firewall | Allows or blocks traffic by rule |
| Load balancer | Spreads traffic across servers and checks their health |
| DNS | Translates names to IP addresses |

## Troubleshooting order

1. Is the device up and has it the right IP?
2. Can it reach its gateway?
3. Can it reach the target by IP?
4. Can it resolve the name?
5. Is a firewall rule or the application port the problem?

Work from the bottom up, and record what you tested and the result.
