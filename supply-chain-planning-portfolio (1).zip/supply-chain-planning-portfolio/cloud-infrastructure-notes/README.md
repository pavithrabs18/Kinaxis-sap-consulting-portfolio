# Cloud Infrastructure Notes

Fundamentals from operating a private cloud platform on VMware for enterprise clients. Concepts only, with no client details.

1. `vmware-basics.md`
2. `network-basics.md`
