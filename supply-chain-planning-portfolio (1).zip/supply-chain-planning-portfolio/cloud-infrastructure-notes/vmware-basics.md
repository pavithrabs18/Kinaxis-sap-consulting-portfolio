# VMware Basics

## Components

| Component | Role |
|---|---|
| ESXi host | The hypervisor that runs virtual machines on a physical server |
| vCenter | Central management of hosts, clusters, and virtual machines |
| Cluster | A group of hosts managed together |
| Datastore | Storage where virtual machine files live |
| Virtual machine | vCPU, memory, disks, and virtual network adapters |

## Common tasks

- **Provision a VM:** choose cluster, datastore, network, and size (vCPU, memory, disk), then install or clone from a template.
- **Resize:** add vCPU, memory, or disk. Some changes need a restart, depending on the guest and settings.
- **vMotion:** live migrate a running VM between hosts with no downtime.
- **Storage vMotion:** live migrate a VM's disks between datastores.
- **Snapshots:** short-lived rollback points. Long-lived snapshots slow the VM and consume storage, so remove them after the change.
- **Patching:** monthly OS updates in a planned window, with a backup and a verified rollback.

## Operating habits

- Check capacity (CPU, memory, storage) before approving a request.
- Follow the SOP, record every change in a ticket, and verify after the change.
- Pull logs from vCenter and the guest when investigating, before any restart.
- Keep requests, approvals, and completion notes in the ticket for audit.
