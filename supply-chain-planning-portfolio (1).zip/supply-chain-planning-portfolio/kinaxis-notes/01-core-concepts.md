# 01. Core Concepts

## What the platform does

RapidResponse is a concurrent planning platform. Supply chain data is held in an in-memory data model, and planning calculations run against it so that users see the effect of a change quickly. Maestro builds on the same foundation with workflow and automation capabilities.

## The layers

| Layer | What it is | Typical owner |
|---|---|---|
| Source systems | ERP, order management, and other systems that hold transactions and master data | Client IT |
| Data integration | Extracts, transformations, and loads into the data model | Integration team |
| Data model | Tables, fields, relationships, and calculated fields | Architecture |
| Resources | Worksheets, workbooks, dashboards, rules, scripts, tasks | Functional and authoring team |
| Users and security | Roles, groups, access control, filters | Administrators |
| Scenarios | Private or shared copies of data for what-if analysis | Planners |

## Key ideas

- **Concurrency:** planning logic recalculates as data or scenarios change, so what-if work does not require a batch run.
- **Scenarios:** a scenario is a branch of the data. Planners can change demand, supply, or parameters, compare against the baseline, and promote or discard the result.
- **Resources:** nearly everything a user touches is a resource. Resources are stored in namespaces and can be grouped for deployment.
- **Environments:** development, QA, and production hold their own data and resources. Moving resources between them is a controlled activity.

## How I read an unfamiliar implementation

1. List the data sources and how often each loads.
2. Identify the core tables that drive planning (parts, sites, demand, supply, BOM, sourcing).
3. Open the main workbooks and trace each worksheet back to its source table.
4. Note the scheduled tasks and the order they run in.
5. Review access control, because it explains most "I can't see it" questions.
