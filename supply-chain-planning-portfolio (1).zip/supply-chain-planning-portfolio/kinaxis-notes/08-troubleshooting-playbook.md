# 08. Troubleshooting Playbook

## General method

1. **Describe it exactly:** who, where, when, what they expected, what happened.
2. **Reproduce it:** same user, same environment, same steps.
3. **Isolate it:** data, configuration, access, or logic?
4. **Change one thing, retest.**
5. **Record the cause and fix**, then check whether the same issue exists in other environments.

## Quick decision tree

| Observation | Probably | Go to |
|---|---|---|
| Empty worksheet for one user only | Access | Note 07 |
| Empty worksheet for everyone | Data load or worksheet filter | Note 06 |
| Different numbers between two users | Scenario or filter | Note 07 |
| Works in QA, fails in production | Configuration drift | Compare control sets, reference tables, task parameters |
| Task failed overnight | Upstream data or dependency | Task log, rejected rows |
| Wrong forecast values | Input history, parameters, or override | Note 04 validation checklist |

## Writing a good defect

- Title with the area and symptom.
- Environment, user, and role.
- Steps to reproduce.
- Expected versus actual, with screenshots.
- Impact and urgency.
- Workaround, if any.

## After the fix

- Retest as the original user.
- Run a related regression check.
- Update the notes or runbook so the next person finds it faster.
