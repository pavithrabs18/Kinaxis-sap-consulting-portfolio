# 06. Data Integration and Automation

## Integration pattern

1. **Extract** from source systems on an agreed schedule.
2. **Transform** to the structure the data model expects, including key mapping and unit conversion.
3. **Load** into the model, with validation and error handling.
4. **Publish** back to downstream systems where needed.

## Common failure causes

| Symptom | Likely cause | First check |
|---|---|---|
| Load rejects rows | Missing reference value, wrong data type, key length | The rejected-row report |
| Row counts drop | Filter or mapping change upstream | Source count versus loaded count |
| Task fails only in one environment | Configuration difference | Control sets, reference tables, task parameters |
| Task succeeds but data looks stale | Wrong schedule or dependency order | Task history and predecessor timing |
| Values off by a factor | Unit of measure conversion | Mapping rules |

## Automation tasks

- Chain tasks in a defined order and make each one idempotent, so a rerun does not duplicate data.
- Log start, end, row counts, and errors for each step.
- Alert a named owner on failure.
- Document the schedule, dependencies, and the restart procedure.

## Daily health check

1. Did every scheduled task finish, and in the expected time?
2. Do loaded counts match source counts within tolerance?
3. Are any resources returning unexpectedly empty results?
4. Are there open errors older than one cycle?

`tools/data_compare.py` helps with step 2 on extracted files.
