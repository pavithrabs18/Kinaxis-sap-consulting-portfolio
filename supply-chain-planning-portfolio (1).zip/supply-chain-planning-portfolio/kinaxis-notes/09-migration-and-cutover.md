# 09. Migration and Cutover

## Analysis phase

- Inventory every resource, table customization, task, integration, and security setup in the source environment.
- Classify each as keep as is, rework, retire, or unknown.
- Document dependencies between resources and between environments.
- List risks with an owner and a mitigation.

## Preparation

- Environment configuration documented for QA and production, with open fields marked for follow-up.
- Cutover plan with task IDs, owners, predecessors, planned dates, and a rollback decision point.
- UAT scripts covering the main business scenarios and regression areas.
- Validation scripts agreed in advance, with pass criteria.

## Validation approach

| Check | Method |
|---|---|
| Table row counts | Source versus target, per table |
| Key coverage | Keys in source missing from target, and the reverse |
| Field values | Compare matching keys on selected fields with a numeric tolerance |
| Resources | Open and run each critical worksheet and compare results |
| Security | Test one user per role |
| Integrations | Run each task end to end |

## Cutover day

- Follow the plan in order and record actual times.
- Stop at decision points and record the decision and who made it.
- Communicate at fixed checkpoints.

## After cutover

- Re-run validation on the live environment.
- Watch the first scheduled runs.
- Hold KT and handover for the support team.
- Record lessons learned.
