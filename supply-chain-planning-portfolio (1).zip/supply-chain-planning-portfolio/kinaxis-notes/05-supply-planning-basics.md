# 05. Supply Planning Basics

## Aggregate supply planning

Aggregate supply planning works at a higher level than detailed material planning. It balances demand against capacity and inventory targets across families, sites, and periods, so decisions about build plans and capacity can be made earlier.

## Core elements

- **Demand:** consensus forecast plus firm orders.
- **Supply:** inventory, planned production, purchases, transfers.
- **Constraints:** capacity, material availability, lead times.
- **Targets:** safety stock, service levels, inventory policy.
- **Horizon and buckets:** monthly or weekly buckets across a planning horizon, with frozen periods near the present.

## The planning equation

Ending inventory in a period equals beginning inventory plus supply minus demand. Shortages and excess show up where the projected balance moves below or above the target.

## Questions a supply review should answer

1. Where is projected inventory below target, and by how much?
2. Is the cause demand, supply timing, or capacity?
3. What are the options: shift supply, add capacity, move demand, or accept the risk?
4. What does each option cost, and what happens to downstream periods?

## Link to demand planning

Demand planning feeds the demand side. If supply planners lose trust in the forecast, they plan around it, so forecast accuracy and bias reviews belong in the same meeting.
