# 10. Certification Study Map

A way to organize preparation for the Kinaxis RapidResponse certification path. Follow the official learning paths for exact scope.

## Level 1 (Solution Consultant)

- Application badges for demand planning and aggregate supply planning.
- Focus: business process understanding, standard application behaviour, configuration basics.

## Level 2 and 3 (in progress)

- Deeper data model, resource authoring, integration, and administration.
- Focus: designing and building solutions, not only configuring them.

## Study cycle

1. Read one topic from the official material.
2. Write a half-page summary from memory.
3. Map it to a real project situation.
4. Do one hands-on exercise.
5. Revisit it a week later.

## Self-check for each topic

- Can I explain it to a new joiner in two minutes?
- Can I name the table or resource involved?
- Can I describe a failure mode and how I would debug it?
