# Glossary

| Term | Meaning |
|---|---|
| ASP | Aggregate supply planning |
| BOM | Bill of materials |
| Consensus demand | The agreed demand plan after input from several functions |
| Control set | A configuration grouping that affects how data and resources behave |
| Data filter | A row-level restriction applied to a user or group |
| Namespace | A container that groups related objects |
| Override | A manual change to a statistical forecast |
| S&OP | Sales and operations planning |
| Scenario | A branch of data for what-if analysis |
| UAT | User acceptance testing |
| Vector table | A table holding time-phased values |
| Worksheet | A resource that shows data from a table with columns, filters, and grouping |
| WAPE | Weighted absolute percent error |
