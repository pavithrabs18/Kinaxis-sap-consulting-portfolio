# Kinaxis Notes

Study notes in my own words, organized to be read in order. Product names and object names vary between versions and models, so treat these as a map and confirm details against the official documentation.

1. `01-core-concepts.md`
2. `02-data-model.md`
3. `03-resource-authoring.md`
4. `04-demand-planning.md`
5. `05-supply-planning-basics.md`
6. `06-data-integration-and-automation.md`
7. `07-access-control-and-visibility.md`
8. `08-troubleshooting-playbook.md`
9. `09-migration-and-cutover.md`
10. `10-certification-study-map.md`
11. `glossary.md`
