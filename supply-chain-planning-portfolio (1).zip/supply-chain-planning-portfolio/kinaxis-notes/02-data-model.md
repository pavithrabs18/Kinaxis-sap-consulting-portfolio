# 02. Data Model

Names below are common examples. Exact tables and fields depend on the model and version in use.

## Table families

| Family | Examples | Purpose |
|---|---|---|
| Item and location | Part, Site, PartSite-style tables | What is planned and where |
| Demand | Independent demand, forecast, customer-related tables | Orders, forecast, and who they belong to |
| Supply | Scheduled receipts, inventory, work orders, purchase orders | What is on hand and on the way |
| Structure and sourcing | BOM, part source, sourcing rules | How items are made or bought |
| Calendars and resources | Calendars, work centers, capacities | When and how much can be produced |
| Reference | Types, statuses, units, control values | Lookup values used across other tables |

## Concepts to be comfortable with

- **Primary keys and relationships:** a record is identified by a combination of fields. Relationships connect tables so a worksheet can pull fields across them.
- **Calculated fields:** fields computed from other fields at run time. Understand the formula before relying on the value.
- **Reference tables:** lookups for allowed values. A missing or mismatched reference value is a common cause of load errors.
- **Namespaces:** group related objects and avoid name collisions between standard and custom content.
- **Vector tables:** hold time-phased data such as buckets of demand or supply across periods.
- **Control sets:** configuration groupings. When two environments differ here, resources can behave differently even if the data is identical.

## Reading a table quickly

1. Find the key fields.
2. Find the relationships out of the table.
3. Check which fields are loaded and which are calculated.
4. Check who writes to it: integration, users, or rules.
