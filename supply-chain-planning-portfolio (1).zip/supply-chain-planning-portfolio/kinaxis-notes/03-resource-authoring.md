# 03. Resource Authoring

## Resource types

Tables and fields, worksheets, workbooks, dashboards, hierarchies, rules and alerts, scorecards, scripts, tasks, and resource groups.

## Worksheets

A worksheet is a query plus a layout.

- **Table and relationships:** start from the table that defines one row of output.
- **Columns:** fields from the table or related tables, or formulas.
- **Filters:** restrict rows. There are worksheet-level filters, user data filters from access control, and scenario scope, and all of them stack.
- **Group by and sort:** control how rows are summarized and shown.
- **Time-phased data:** worksheets can show buckets of a vector table across a time range.

## Workbooks and dashboards

- A workbook bundles worksheets, charts, and commands for a role or task.
- A dashboard presents several views at once and drives user actions.
- Design for a person doing a job. Name the workbook after the task.

## Authoring habits that save time

1. Build a worksheet on a small filter first, then widen it.
2. Name columns for business users and keep technical names in notes.
3. Reuse shared filters and hierarchies rather than copying them.
4. Test as a user with a restricted role, not only as an administrator.
5. Keep a change log of what moved between environments.

## Typical review questions

- Does the worksheet answer one question clearly?
- Is any filter hiding data by accident?
- Does it perform acceptably with production volume?
- Is the resource in the right namespace and resource group?
