# 04. Demand Planning

General demand planning concepts, mapped to how I validate them in an implementation. Kinaxis-specific configuration should be confirmed against the product documentation.

## The process

1. **History:** clean sales or shipment history at the planning level (for example item by customer group by month).
2. **Baseline statistical forecast:** generated from history using time-series methods.
3. **Overrides and adjustments:** planners adjust for promotions, new items, lost customers, and known events.
4. **Consensus:** sales, marketing, finance, and operations agree on one demand number.
5. **S&OP review:** consensus demand is compared with supply and financial targets.
6. **Measure:** forecast accuracy and bias feed back into the next cycle.

## Statistical methods, in plain terms

| Method | Good for | Watch out for |
|---|---|---|
| Moving average | Stable demand | Lags trends |
| Simple exponential smoothing | Level only, no trend or season | Flat forecast when there is a trend |
| Trend methods (Holt) | Trending demand | Overshoots when trend ends |
| Seasonal methods (Holt-Winters) | Repeating seasonal pattern | Needs enough seasons of history |
| Intermittent methods (Croston style) | Sparse, lumpy demand | Standard accuracy metrics mislead |

`tools/forecast_metrics.py` implements a few of these so a baseline can be sanity checked outside the platform.

## Accuracy and bias

- **MAE:** average absolute error, in units.
- **MAPE:** average absolute percent error. Undefined when actual is zero and unstable for small volumes.
- **WAPE (weighted MAPE):** total absolute error divided by total actual. Better for portfolios because large items count more.
- **Bias:** total forecast minus total actual, relative to actual. Positive means over-forecasting.
- **Tracking signal:** cumulative error divided by MAE. A value outside about plus or minus 4 suggests persistent bias.

## Validation checklist I use

- Master data: every planned item has a hierarchy, a unit of measure, and a status.
- History: totals by period match the source system within an agreed tolerance.
- Outliers: large spikes are investigated and either kept or flagged.
- Forecast output: compare platform output against an independent calculation for a sample of items.
- Overrides: confirm they persist, roll up and disaggregate as expected.
- Scenarios: change an input, confirm the result changes, and confirm the baseline does not.
- Consensus: confirm each role can see and edit only its own inputs.

## Test data

Small, hand-built datasets are useful. Include a flat item, a trending item, a seasonal item, a new item with no history, and an intermittent item, and know the expected result for each before running.
