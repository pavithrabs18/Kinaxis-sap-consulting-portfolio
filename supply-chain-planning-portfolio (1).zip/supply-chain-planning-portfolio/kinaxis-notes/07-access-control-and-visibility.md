# 07. Access Control and Data Visibility

## Layers that decide what a user sees

1. **Roles and permissions:** which resources and commands the user can use.
2. **Data filters:** which rows of data the user can see, often on part, site, or customer related tables.
3. **Resource filters:** filters built into the worksheet itself.
4. **Scenario:** private scenarios hold their own data, so a user can see different values from a colleague.

## Typical design

- Group users by function (demand planner, supply planner, viewer, administrator).
- Give each group the minimum roles needed.
- Express data restrictions as filters tied to groups, so a new user inherits them automatically.

## Common issues

- A filter references a value that does not exist in the loaded data, so everything is hidden.
- A filter is applied on one table but the worksheet starts from another, so the filter has no effect or an unexpected effect.
- A user belongs to two groups with conflicting filters.
- Roles were copied between environments but filters were not.

## Debugging steps

1. Reproduce as the affected user, not as an administrator.
2. Compare with a user who can see the data and list the differences in groups, roles, and filters.
3. Test the worksheet with the data filter removed (as an administrator) to confirm the data exists.
4. Fix one thing at a time and retest in a fresh session.
