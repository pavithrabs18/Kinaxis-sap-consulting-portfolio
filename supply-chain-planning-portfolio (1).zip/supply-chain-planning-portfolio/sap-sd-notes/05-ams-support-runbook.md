# 05. AMS Support Runbook

## Daily routine

1. Review the overnight job and interface status.
2. Review open tickets by priority and age.
3. Run the order, delivery, and billing health checks below.
4. Post a short status note to the client channel.

## Health checks

| Check | Question |
|---|---|
| Orders | Any orders stuck with incompletion, credit block, or no confirmed schedule lines? |
| Deliveries | Any deliveries due but not created or not goods-issued? |
| Billing | Anything on the billing due list past its date? Any billing documents with accounting errors? |
| Interfaces | Any failed IDocs or interface messages? |
| Data | Spot check pricing and tax on a sample of new orders |

## Ticket handling

1. Acknowledge within the agreed response time.
2. Reproduce and gather the document numbers, user, and time.
3. Identify the cause: data, configuration, authorization, process, or defect.
4. Fix or workaround, with approval where a change is involved.
5. Confirm with the user, record the cause and resolution, and close.

## Transition and go-live support

- Shadow the incumbent team and collect their runbooks and known issues.
- Receive KT in structured sessions and record each one.
- Perform reverse KT: explain the process back to confirm understanding.
- During hypercare, hold a short daily review of new issues and trends.
- Convert repeated issues into knowledge articles.

## Bilingual support tips

- Confirm requirements in writing in both languages after a meeting.
- Keep a shared term list so that translated documents stay consistent.
- Put document numbers and screenshots in every ticket so the language of the description matters less.
