# 04. Special Processes

## Returns

- Customer returns goods, a returns order is created referencing the original invoice or order.
- Returns delivery receives the goods back into stock.
- A credit memo is created for the credit.
- Check returns reason, return-to-stock or scrap decision, and billing block for approval.

## Credit and debit memos

- **Credit memo request** leads to a credit memo that reduces the customer's balance (price corrections, quality complaints).
- **Debit memo request** leads to a debit memo that increases it (undercharging, extra charges).
- Both can be blocked for review before billing.

## Rush orders and cash sales

- **Rush order:** a delivery is created automatically with the order, and billing follows later.
- **Cash sale:** delivery and billing happen immediately at order entry.

## Collective processing

- **Collective delivery:** several orders for the same ship-to and shipping conditions are combined in one delivery.
- **Collective billing:** several deliveries are billed together on one invoice where the billing criteria match.

## Free of charge and sample deliveries

Use a dedicated order type and item category so that delivery happens without billing, and so that accounting and reporting treat it correctly.

## Support tips

- Ask which document type was used first, because most behavior follows from it.
- Check copy control settings when a document flow behaves unexpectedly.
- Check billing blocks and partner functions before assuming a configuration defect.
