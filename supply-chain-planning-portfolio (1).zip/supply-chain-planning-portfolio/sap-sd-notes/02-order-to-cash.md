# 02. Order-to-Cash

## The standard flow

| Step | Document | What happens |
|---|---|---|
| Inquiry (optional) | Inquiry | Customer asks for information |
| Quotation (optional) | Quotation | Binding offer with a validity period |
| Sales order | Standard order | Customer commitment: pricing, availability check, schedule lines, credit check |
| Delivery | Outbound delivery | Picking, packing, and goods issue |
| Billing | Invoice | Billing document creation and accounting posting |
| Payment | Incoming payment | Cash application in finance |

## Document flow

Each document links to its predecessor, so the full chain from quotation to invoice can be traced. Use the document flow view on any document to see it.

## What each step checks

- **Order:** pricing, availability (ATP), credit, incompletion log, partner determination, shipping point, route.
- **Delivery:** stock availability, picking, packing, goods issue, which reduces stock and posts to accounting.
- **Billing:** billing block, billing date, pricing carried from the order, accounting interface.

## Typical status questions in support

| Question | Where to look |
|---|---|
| Why is the order blocked? | Delivery block, billing block, credit block fields on the header |
| Why can't I deliver? | Incompletion log, stock, shipping point, delivery block |
| Why isn't it billed? | Billing block, goods issue status, billing due list |
| Why did billing fail to post? | Billing document accounting status and the error log |
