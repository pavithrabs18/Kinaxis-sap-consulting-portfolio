# 01. Organizational Structure and Master Data

## Sales organizational structure

| Element | Meaning |
|---|---|
| Client | The top-level technical unit of the system |
| Company code | Legal entity for financial accounting |
| Sales organization | Responsible for selling and distributing products, owns the terms of sale |
| Distribution channel | The route to the customer (direct, wholesale, online) |
| Division | A product grouping |
| Sales area | A combination of sales organization, distribution channel, and division |
| Plant | Where goods are stored or produced |
| Shipping point | Where deliveries are processed and shipped from |
| Storage location | A stock location within a plant |

A customer is sold to within a sales area, so customer and material data must exist for that sales area before an order can be created.

## Master data

- **Business partner / customer:** in S/4HANA, customers are maintained through the business partner concept. Partner functions include sold-to, ship-to, bill-to, and payer.
- **Material master:** views for basic data, sales, plant and storage, MRP, and accounting. Sales views drive item category determination and availability checks.
- **Condition records:** prices, discounts, surcharges, and taxes stored against condition types.
- **Customer-material info record:** customer-specific material numbers and descriptions.
- **Output and text master data:** document output (order confirmations, invoices) and texts.

## Common master data causes of order errors

- Material not extended to the sales area.
- Missing partner function on the customer.
- No condition record found for the price condition.
- Plant or shipping point not determined.
- Incomplete material master view (for example MRP type missing).
