# Common Transactions and Tables

Transactions and table names are standard but check availability in your S/4HANA release.

## Transactions

| Code | Purpose |
|---|---|
| VA01, VA02, VA03 | Create, change, display sales order |
| VA05 | List of sales orders |
| VL01N, VL02N, VL03N | Create, change, display outbound delivery |
| VL06O | Outbound delivery monitor |
| VF01, VF02, VF03 | Create, change, display billing document |
| VF04 | Billing due list |
| VK11, VK12, VK13 | Create, change, display condition records |
| VOFM | Maintain routines and requirements |
| SE16N | Table display |
| SU53 | Display authorization check failure |
| SM37 | Job overview |
| WE02 | IDoc display |

## Tables

| Table | Content |
|---|---|
| VBAK | Sales document header |
| VBAP | Sales document item |
| VBEP | Schedule lines |
| VBFA | Sales document flow |
| LIKP | Delivery header |
| LIPS | Delivery item |
| VBRK | Billing document header |
| VBRP | Billing document item |
| KNA1 | Customer general data |
| KNVV | Customer sales area data |
| MARA | Material general data |
| MVKE | Material sales data |
| T184L | Schedule line category determination |
