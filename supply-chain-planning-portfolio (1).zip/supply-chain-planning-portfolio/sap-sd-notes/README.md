# SAP SD Notes

Study and support notes for SAP S/4HANA Sales (order-to-cash). Written from AMS support and shadowing experience, in my own words. Configuration details differ by system, so confirm against your landscape.

1. `01-org-structure-and-master-data.md`
2. `02-order-to-cash.md`
3. `03-pricing-and-schedule-lines.md`
4. `04-special-processes.md`
5. `05-ams-support-runbook.md`
6. `tcodes-and-tables.md`
