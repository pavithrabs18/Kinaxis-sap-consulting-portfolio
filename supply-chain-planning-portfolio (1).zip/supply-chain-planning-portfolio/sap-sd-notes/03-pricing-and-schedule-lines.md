# 03. Pricing and Schedule Lines

## Pricing: the condition technique

1. **Condition table:** the combination of fields a price depends on (for example customer and material).
2. **Access sequence:** the ordered list of condition tables searched for a record. The first record found wins.
3. **Condition type:** the kind of price element (base price, discount, surcharge, tax, freight).
4. **Pricing procedure:** the ordered list of condition types for a document, with subtotals, requirements, and calculation types.
5. **Determination:** the pricing procedure is found from sales area, customer pricing procedure, and document pricing procedure.

## Common pricing errors

- No record found: check the condition record, its validity dates, and the key fields.
- Wrong price: check the access sequence order and any manual price override.
- Missing tax: check the tax classification on customer and material and the tax condition records.

## Item categories and schedule line categories

- The **item category** controls how an item behaves in the document (relevant for delivery, billing, pricing, and so on). It is determined from the sales document type, the item category group of the material, usage, and higher-level item category.
- The **schedule line category** controls whether a schedule line is relevant for MRP and delivery, and whether availability is checked. It is determined from the item category and the MRP type of the material.
- Typical examples are one category that passes requirements to MRP and one that does not.

## Availability check

- Checked per schedule line, based on the checking group and checking rule.
- Confirms quantity on a date based on stock, planned receipts, and planned issues.
- If stock is short, the confirmed quantity and date may differ from the request, and the order shows partial confirmation.

## Debugging a schedule line problem

1. Open the item and check the schedule line category and confirmed quantity.
2. Check the material MRP type and checking group.
3. Check the item category and its determination inputs.
4. Compare with an order that behaves correctly.
