#!/usr/bin/env python3
"""Forecast accuracy metrics and simple baseline forecasts (standard library only)."""
import argparse
import csv
import math
import sys


def mae(actual, forecast):
    return sum(abs(a - f) for a, f in zip(actual, forecast)) / len(actual)


def rmse(actual, forecast):
    return math.sqrt(sum((a - f) ** 2 for a, f in zip(actual, forecast)) / len(actual))


def mape(actual, forecast):
    """Mean absolute percent error. Periods with zero actual are skipped."""
    pairs = [(a, f) for a, f in zip(actual, forecast) if a != 0]
    if not pairs:
        return None
    return sum(abs(a - f) / abs(a) for a, f in pairs) / len(pairs)


def wape(actual, forecast):
    total = sum(abs(a) for a in actual)
    if total == 0:
        return None
    return sum(abs(a - f) for a, f in zip(actual, forecast)) / total


def bias_pct(actual, forecast):
    """Positive means over-forecast."""
    total = sum(actual)
    if total == 0:
        return None
    return (sum(forecast) - total) / total


def tracking_signal(actual, forecast):
    """Cumulative error divided by MAE. Values beyond about +/-4 suggest persistent bias."""
    m = mae(actual, forecast)
    if m == 0:
        return 0.0
    return sum(f - a for a, f in zip(actual, forecast)) / m


def moving_average(history, window, horizon):
    if window < 1 or len(history) < window:
        raise ValueError("history shorter than window")
    value = sum(history[-window:]) / window
    return [value] * horizon


def simple_exponential_smoothing(history, alpha, horizon):
    if not 0 < alpha <= 1:
        raise ValueError("alpha must be in (0, 1]")
    level = history[0]
    for x in history[1:]:
        level = alpha * x + (1 - alpha) * level
    return [level] * horizon


def seasonal_naive(history, season_length, horizon):
    if len(history) < season_length:
        raise ValueError("history shorter than one season")
    return [history[-season_length + (i % season_length)] for i in range(horizon)]


def read_column_csv(path, columns):
    rows = []
    with open(path, newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        for col in columns:
            if col not in (reader.fieldnames or []):
                raise ValueError("missing column: " + col)
        for row in reader:
            rows.append(row)
    return rows


def fmt(value, pct=False):
    if value is None:
        return "n/a"
    return "{:.2%}".format(value) if pct else "{:.2f}".format(value)


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("csv_file")
    p.add_argument("--baseline", choices=["ma", "ses", "snaive"],
                   help="generate a baseline forecast from a 'actual' column instead of scoring")
    p.add_argument("--window", type=int, default=3)
    p.add_argument("--alpha", type=float, default=0.3)
    p.add_argument("--season", type=int, default=12)
    p.add_argument("--horizon", type=int, default=3)
    args = p.parse_args(argv)

    if args.baseline:
        rows = read_column_csv(args.csv_file, ["actual"])
        history = [float(r["actual"]) for r in rows]
        if args.baseline == "ma":
            out = moving_average(history, args.window, args.horizon)
        elif args.baseline == "ses":
            out = simple_exponential_smoothing(history, args.alpha, args.horizon)
        else:
            out = seasonal_naive(history, args.season, args.horizon)
        for i, v in enumerate(out, 1):
            print("t+{}: {:.2f}".format(i, v))
        return 0

    rows = read_column_csv(args.csv_file, ["actual", "forecast"])
    actual = [float(r["actual"]) for r in rows]
    forecast = [float(r["forecast"]) for r in rows]
    print("Periods:          {}".format(len(actual)))
    print("MAE:              {}".format(fmt(mae(actual, forecast))))
    print("RMSE:             {}".format(fmt(rmse(actual, forecast))))
    print("MAPE:             {}".format(fmt(mape(actual, forecast), True)))
    print("WAPE:             {}".format(fmt(wape(actual, forecast), True)))
    print("Bias:             {}".format(fmt(bias_pct(actual, forecast), True)))
    print("Tracking signal:  {}".format(fmt(tracking_signal(actual, forecast))))
    return 0


if __name__ == "__main__":
    sys.exit(main())
