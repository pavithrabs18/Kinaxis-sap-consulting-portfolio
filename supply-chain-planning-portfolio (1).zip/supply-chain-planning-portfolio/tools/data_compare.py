#!/usr/bin/env python3
"""Compare a source CSV with a target CSV by key columns (standard library only)."""
import argparse
import csv
import sys


def load(path, keys):
    with open(path, newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        fields = reader.fieldnames or []
        for k in keys:
            if k not in fields:
                raise ValueError("key column '{}' not found in {}".format(k, path))
        data = {}
        duplicates = []
        for row in reader:
            key = tuple(row[k].strip() for k in keys)
            if key in data:
                duplicates.append(key)
            data[key] = row
    return fields, data, duplicates


def values_equal(a, b, tolerance):
    a, b = (a or "").strip(), (b or "").strip()
    if a == b:
        return True
    try:
        return abs(float(a) - float(b)) <= tolerance
    except ValueError:
        return False


def compare(source, target, keys, tolerance=0.0):
    s_fields, s_data, s_dups = load(source, keys)
    t_fields, t_data, t_dups = load(target, keys)
    common_fields = [f for f in s_fields if f in t_fields and f not in keys]
    result = {
        "source_rows": len(s_data),
        "target_rows": len(t_data),
        "missing_in_target": sorted(set(s_data) - set(t_data)),
        "extra_in_target": sorted(set(t_data) - set(s_data)),
        "duplicate_keys_source": s_dups,
        "duplicate_keys_target": t_dups,
        "fields_only_in_source": [f for f in s_fields if f not in t_fields],
        "fields_only_in_target": [f for f in t_fields if f not in s_fields],
        "mismatches": [],
    }
    for key in sorted(set(s_data) & set(t_data)):
        for f in common_fields:
            if not values_equal(s_data[key][f], t_data[key][f], tolerance):
                result["mismatches"].append((key, f, s_data[key][f], t_data[key][f]))
    return result


def has_differences(r):
    return bool(r["missing_in_target"] or r["extra_in_target"] or r["mismatches"]
                or r["duplicate_keys_source"] or r["duplicate_keys_target"]
                or r["fields_only_in_source"] or r["fields_only_in_target"]
                or r["source_rows"] != r["target_rows"])


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("source")
    p.add_argument("target")
    p.add_argument("--keys", required=True, help="comma separated key columns")
    p.add_argument("--tolerance", type=float, default=0.0, help="numeric tolerance")
    p.add_argument("--report", help="write differences to this CSV file")
    args = p.parse_args(argv)
    keys = [k.strip() for k in args.keys.split(",")]

    r = compare(args.source, args.target, keys, args.tolerance)
    print("Source rows:           {}".format(r["source_rows"]))
    print("Target rows:           {}".format(r["target_rows"]))
    print("Missing in target:     {}".format(len(r["missing_in_target"])))
    print("Extra in target:       {}".format(len(r["extra_in_target"])))
    print("Field mismatches:      {}".format(len(r["mismatches"])))
    print("Duplicate keys (src):  {}".format(len(r["duplicate_keys_source"])))
    print("Duplicate keys (tgt):  {}".format(len(r["duplicate_keys_target"])))
    if r["fields_only_in_source"]:
        print("Fields only in source: " + ", ".join(r["fields_only_in_source"]))
    if r["fields_only_in_target"]:
        print("Fields only in target: " + ", ".join(r["fields_only_in_target"]))

    if args.report:
        with open(args.report, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["type", "key", "field", "source_value", "target_value"])
            for k in r["missing_in_target"]:
                w.writerow(["missing_in_target", "|".join(k), "", "", ""])
            for k in r["extra_in_target"]:
                w.writerow(["extra_in_target", "|".join(k), "", "", ""])
            for k, f, sv, tv in r["mismatches"]:
                w.writerow(["mismatch", "|".join(k), f, sv, tv])
        print("Report written to " + args.report)

    return 1 if has_differences(r) else 0


if __name__ == "__main__":
    sys.exit(main())
