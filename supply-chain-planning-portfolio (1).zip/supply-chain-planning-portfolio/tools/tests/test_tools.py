import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

import forecast_metrics as fm  # noqa: E402
import data_compare as dc  # noqa: E402

SAMPLE = os.path.join(os.path.dirname(HERE), "sample-data")


class ForecastTests(unittest.TestCase):
    def test_perfect_forecast(self):
        a = [10, 20, 30]
        self.assertEqual(fm.mae(a, a), 0)
        self.assertEqual(fm.wape(a, a), 0)
        self.assertEqual(fm.bias_pct(a, a), 0)

    def test_wape_and_bias(self):
        a = [100, 100]
        f = [110, 90]
        self.assertAlmostEqual(fm.wape(a, f), 0.10)
        self.assertAlmostEqual(fm.bias_pct(a, f), 0.0)

    def test_mape_skips_zero_actuals(self):
        self.assertAlmostEqual(fm.mape([0, 100], [5, 110]), 0.10)
        self.assertIsNone(fm.mape([0, 0], [1, 1]))

    def test_tracking_signal_detects_bias(self):
        self.assertGreater(fm.tracking_signal([100] * 6, [110] * 6), 4)

    def test_moving_average(self):
        self.assertEqual(fm.moving_average([1, 2, 3, 4], 2, 2), [3.5, 3.5])

    def test_ses_flat_series(self):
        self.assertEqual(fm.simple_exponential_smoothing([5, 5, 5], 0.5, 2), [5, 5])

    def test_seasonal_naive(self):
        self.assertEqual(fm.seasonal_naive([1, 2, 3, 4], 2, 4), [3, 4, 3, 4])

    def test_cli_runs(self):
        self.assertEqual(fm.main([os.path.join(SAMPLE, "forecast_sample.csv")]), 0)


class CompareTests(unittest.TestCase):
    def test_sample_differences(self):
        r = dc.compare(os.path.join(SAMPLE, "source.csv"),
                       os.path.join(SAMPLE, "target.csv"), ["part", "site"], 0.01)
        self.assertEqual(r["missing_in_target"], [("P-300", "S2")])
        self.assertEqual(r["extra_in_target"], [("P-400", "S2")])
        self.assertEqual(r["mismatches"], [])
        self.assertTrue(dc.has_differences(r))

    def test_tolerance_matters(self):
        r = dc.compare(os.path.join(SAMPLE, "source.csv"),
                       os.path.join(SAMPLE, "target.csv"), ["part", "site"], 0.0)
        self.assertEqual(len(r["mismatches"]), 1)

    def test_identical_files_match(self):
        s = os.path.join(SAMPLE, "source.csv")
        r = dc.compare(s, s, ["part", "site"])
        self.assertFalse(dc.has_differences(r))


if __name__ == "__main__":
    unittest.main()
