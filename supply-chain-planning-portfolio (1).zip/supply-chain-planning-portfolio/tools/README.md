# Tools

Small Python tools using only the standard library (Python 3.8 or later).

## forecast_metrics.py

Computes forecast accuracy metrics from a CSV with `period,actual,forecast` columns, and can generate simple baseline forecasts to compare with a platform's output.

```
python3 forecast_metrics.py sample-data/forecast_sample.csv
python3 forecast_metrics.py sample-data/history_sample.csv --baseline ses --alpha 0.3 --horizon 3
python3 forecast_metrics.py sample-data/history_sample.csv --baseline ma --window 3 --horizon 3
```

Metrics: MAE, RMSE, MAPE (zero actuals skipped), WAPE, bias percent, and tracking signal.

## data_compare.py

Compares a source CSV with a target CSV by key columns. Reports row counts, keys missing in the target, keys extra in the target, and field mismatches with an optional numeric tolerance.

```
python3 data_compare.py sample-data/source.csv sample-data/target.csv --keys part,site
python3 data_compare.py sample-data/source.csv sample-data/target.csv --keys part,site --tolerance 0.01 --report out.csv
```

Exit code is 0 when everything matches and 1 when differences are found, so it can be used in a script.

## Tests

```
python3 -m unittest discover tests
```
