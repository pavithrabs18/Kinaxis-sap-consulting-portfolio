# Weekly Status Report

- Project:
- Week ending:
- Overall status:

## Done this week

## Planned next week

## Risks and issues

## Decisions needed

## Dates and milestones
