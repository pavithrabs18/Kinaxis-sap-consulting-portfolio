# Templates

Plain files you can open in Excel or Google Sheets, or in any text editor. They contain headers and one dummy row only.

- `kt-tracker.csv`
- `uat-tracker.csv`
- `cutover-plan.csv`
- `data-validation.csv`
- `forecast-validation.csv`
- `jira-breakdown.csv`
- `raid-log.csv`
- `ticket-log.csv`
- `kt-session.md`
- `sop.md`
- `status-report.md`
