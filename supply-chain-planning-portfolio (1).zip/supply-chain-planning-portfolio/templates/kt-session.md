# KT Session

- Topic:
- Date:
- Trainer:
- Attendees:
- Recording link:

## Agenda

## Key points

## Demo or example used

## Open questions and owners

## Reverse KT

- Done by:
- Date:
- Gaps found:
